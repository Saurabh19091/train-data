# yolov5_1 > 2025-01-16 9:40pm
https://universe.roboflow.com/tech-qbqqr/yolov5_1-icrxp

Provided by a Roboflow user
License: CC BY 4.0

